# minheap.py
class MinHeap0:
    def __init__(self, *args):
        if len(args) != 0:
            self.__A = args[0]
        else:
            self.__A = []

    def insert(self, x):
        self.__A.append(x)
        self.__percolateUp(len(self.__A) - 1)
    
    def insert_count(self, x):
        for i in range(len(self.__A)):
            if self.__A[i][0] == x[0]:
                self.__A[i][1] += 0               # 아무리 생각해도 1이나 왜 0인지 모르겠음....0으로 하면 돌아감
                                                #이거는 0인 이유가 lfu_sim의 if lpn in lpn_freq_dict: lpn_freq_dict[lpn][1] += 1 에서 이미 1을 더해서인 것 같아
                self.__percolateDown(i)
                return

    def __percolateUp(self, i: int):
        parent = (i - 1) // 2
        if i > 0 and self.__A[i][1] < self.__A[parent][1]:
            self.__A[i], self.__A[parent] = self.__A[parent], self.__A[i]
            self.__percolateUp(parent)

    def deleteMin(self):
        if not self.isEmpty():
            min_val = self.__A[0]
            self.__A[0] = self.__A[-1]
            del self.__A[-1]
            self.__percolateDown(0)
            return min_val
        return None

    def __percolateDown(self, i: int):
        left = 2 * i + 1
        right = 2 * i + 2
        smallest = i

        if left < len(self.__A) and self.__A[left][1] < self.__A[smallest][1]:
            smallest = left
        if right < len(self.__A) and self.__A[right][1] < self.__A[smallest][1]:
            smallest = right

        if smallest != i:
            self.__A[i], self.__A[smallest] = self.__A[smallest], self.__A[i]
            self.__percolateDown(smallest)

    def isEmpty(self) -> bool:
        return len(self.__A) == 0

    def size(self) -> int:
        return len(self.__A)

    def heapPrint(self):
        depth = 0
        count = 0
        print("===========================")
        while count < len(self.__A):
            for i in range(2 ** depth):
                if count < len(self.__A):
                    print(self.__A[count], end=" ")
                count += 1
            print()
            depth += 1
        print()
